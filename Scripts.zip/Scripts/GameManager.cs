﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager ins;

    //Container
    public GameObject container1, container2;

    //Quests
    public GameObject goEnd;
    private GameObject quest1, quest2, quest3, quest4, quest5, quest6, quest7, quest8, quest9, quest10;
    private Button correct1, correct2, correct3, correct4, correct5, correct6, correct7, correct8, correct9, correct10;
    public Button again, exit;
    public bool moveOn = true;
    
    

    //Controles inGAME
    public bool gameover = false;
    

    void Awake()
    {
        if (ins == null)
        {
            ins = this;
            DontDestroyOnLoad(gameObject);
        }

        else
        {
            Destroy(gameObject);
        }
        SceneManager.sceneLoaded += Carrega;

    }

    void Carrega(Scene cena, LoadSceneMode modo)
    {
        PegaDados();
    }

    void PegaDados()
    {
        
        //Container
        container1 = GameObject.FindWithTag("Quests");
        container2 = GameObject.FindWithTag("Ending");
        //UI
        goEnd = container2.transform.GetChild(0).gameObject;
        quest1 = container1.transform.GetChild(0).gameObject;
        quest2 = container1.transform.GetChild(1).gameObject;
        quest3 = container1.transform.GetChild(2).gameObject;
        quest4 = container1.transform.GetChild(3).gameObject;
        quest5 = container1.transform.GetChild(4).gameObject;
        quest6 = container1.transform.GetChild(5).gameObject;
        quest7 = container1.transform.GetChild(6).gameObject;
        quest8 = container1.transform.GetChild(7).gameObject;
        quest9 = container1.transform.GetChild(8).gameObject;
        quest10 = container1.transform.GetChild(9).gameObject;
        correct1 = container1.transform.GetChild(0).GetChild(1).GetComponent<Button>();
        correct2 = container1.transform.GetChild(1).GetChild(1).GetComponent<Button>();
        correct3 = container1.transform.GetChild(2).GetChild(1).GetComponent<Button>();
        correct4 = container1.transform.GetChild(3).GetChild(1).GetComponent<Button>();
        correct5 = container1.transform.GetChild(4).GetChild(1).GetComponent<Button>();
        correct6 = container1.transform.GetChild(5).GetChild(1).GetComponent<Button>();
        correct7 = container1.transform.GetChild(6).GetChild(1).GetComponent<Button>();
        correct8 = container1.transform.GetChild(7).GetChild(1).GetComponent<Button>();
        correct9 = container1.transform.GetChild(8).GetChild(1).GetComponent<Button>();
        correct10 = container1.transform.GetChild(9).GetChild(1).GetComponent<Button>();
        exit = container2.transform.GetChild(0).GetChild(1).GetComponent<Button>();
        again = container2.transform.GetChild(0).GetChild(2).GetComponent<Button>();    
        //Events
        correct1.onClick.AddListener(RespostaCorreta1);
        correct2.onClick.AddListener(RespostaCorreta2);
        correct3.onClick.AddListener(RespostaCorreta3);
        correct4.onClick.AddListener(RespostaCorreta4);
        correct5.onClick.AddListener(RespostaCorreta5);
        correct6.onClick.AddListener(RespostaCorreta6);
        correct7.onClick.AddListener(RespostaCorreta7);
        correct8.onClick.AddListener(RespostaCorreta8);
        correct9.onClick.AddListener(RespostaCorreta9);
        correct10.onClick.AddListener(RespostaCorreta10);
        again.onClick.AddListener(PlayAgain);
        exit.onClick.AddListener(ExitGame);

        Restart();
    }

    void Start()
    {
        Restart();
    }

    void Update()
    {
        if(gameover && !goEnd.gameObject.activeSelf)
        {
            GameOver();
        }
    }

    public void Ativar1()
    {
        Time.timeScale = 0;
        moveOn = false;
        quest1.gameObject.SetActive(true);
    }
    public void Ativar2()
    {
        Time.timeScale = 0;
        moveOn = false;
        quest2.gameObject.SetActive(true);
    }
    public void Ativar3()
    {
        Time.timeScale = 0;
        moveOn = false;
        quest3.gameObject.SetActive(true);
    }
    public void Ativar4()
    {
        Time.timeScale = 0;
        moveOn = false;
        quest4.gameObject.SetActive(true);
    }
    public void Ativar5()
    {
        Time.timeScale = 0;
        moveOn = false;
        quest5.gameObject.SetActive(true);
    }
    public void Ativar6()
    {
        Time.timeScale = 0;
        moveOn = false;
        quest6.gameObject.SetActive(true);
    }
    public void Ativar7()
    {
        Time.timeScale = 0;
        quest7.gameObject.SetActive(true);
        moveOn = false;
    }
    public void Ativar8()
    {
        Time.timeScale = 0;
        moveOn = false;
        quest8.gameObject.SetActive(true);
    }
    public void Ativar9()
    {
        Time.timeScale = 0;
        moveOn = false;
        quest9.gameObject.SetActive(true);
    }
    public void Ativar10()
    {
        Time.timeScale = 0;
        moveOn = false;
        quest10.gameObject.SetActive(true);
    }

    public void RespostaCorreta1()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest1.gameObject.SetActive(false);
    }
    public void RespostaCorreta2()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest2.gameObject.SetActive(false);
    }
    public void RespostaCorreta3()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest3.gameObject.SetActive(false);
    }
    public void RespostaCorreta4()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest4.gameObject.SetActive(false);
    }
    public void RespostaCorreta5()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest5.gameObject.SetActive(false);
    }
    public void RespostaCorreta6()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest6.gameObject.SetActive(false);
    }
    public void RespostaCorreta7()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest7.gameObject.SetActive(false);
    }
    public void RespostaCorreta8()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest8.gameObject.SetActive(false);
    }
    public void RespostaCorreta9()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest9.gameObject.SetActive(false);
    }
    public void RespostaCorreta10()
    {
        Time.timeScale = 1;
        moveOn = true;
        quest10.gameObject.SetActive(false);
    }

    void Restart()
    {
        moveOn = true;
        gameover = false;
        goEnd.gameObject.SetActive(false);
        Time.timeScale = 1;
    }

    void PlayAgain()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    void ExitGame()
    {
        Application.Quit();
    }

    void GameOver()
    {
        //Canvas
        goEnd.gameObject.SetActive(true);
        //Quests
        quest1.gameObject.SetActive(false);
        quest2.gameObject.SetActive(false);
        quest3.gameObject.SetActive(false);
        quest4.gameObject.SetActive(false);
        quest5.gameObject.SetActive(false);
        quest6.gameObject.SetActive(false);
        quest7.gameObject.SetActive(false);
        quest8.gameObject.SetActive(false);
        quest9.gameObject.SetActive(false);
        quest10.gameObject.SetActive(false);
        //Moviment
        moveOn = false;
    }
}
