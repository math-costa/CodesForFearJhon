﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LifeManager : MonoBehaviour
{
    public static LifeManager ins;

    public GameObject Player;
    public int maxLife = 100;
    public int currentLife = 100;
    Transform t;
    public float fixedRotation = 0;

    void Awake()
    {
        if (ins == null)
        {
            ins = this;
        }
    }

    void Start()
    {
        t = transform;
        //Controles
        Player = GameObject.FindWithTag("Player").gameObject;
    }

    void Update()
    {
        transform.localScale = new Vector3(currentLife * 100 / maxLife , 10 , 1);
        t.eulerAngles = new Vector3(t.eulerAngles.x, fixedRotation, t.eulerAngles.z);
    }


    public void Dano()
    {
        if (currentLife > 0)
        {
            currentLife -= 10;
        }
        else
        {
            GameManager.ins.gameover = true;
            //Destroy(Player);
        }
    }
}
