﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//codigo para destruiçao de objetos quando o jogador responde as resposta corretamente
public class Destroy1 : MonoBehaviour
{
    //chama o codigo do "Open" para quando ele verdade destruir o item com esse codigo
    public void Update() 
    {
        if (Questao1.Q1.DS1 == true){
            Destroy(gameObject);
        }
    }
}
