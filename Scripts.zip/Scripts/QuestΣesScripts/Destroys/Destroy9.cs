﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy9 : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    //chama o codigo do "Open" para quando ele e verdade destruir o item com esse codigo
    public void Update()
    {
        if (Questao9.Q9.DS9 == true)
        {
            Destroy(gameObject);
        }
    }
}