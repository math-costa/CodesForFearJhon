﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy7 : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    //chama o codigo do "Open" para quando ele e verdade destruir o item com esse codigo
    public void Update()
    {
        if (Questao71.Q71.DS71 == true && Questao72.Q72.DS72 == true)
        {
            Destroy(gameObject);
        }
    }
}
