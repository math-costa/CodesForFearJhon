﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy6 : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    //chama o codigo do "Open" para quando ele e verdade destruir o item com esse codigo
    public void Update()
    {
        if (Questao6R.Q6R.DS6R == true && Questao6E.Q6E.DS6E == true && Questao6E.Q6E.DS6E == true && Questao6D.Q6D.DS6D == true && Questao6N.Q6N.DS6N == true)
        {
            Destroy(gameObject);
        }
    }
}
