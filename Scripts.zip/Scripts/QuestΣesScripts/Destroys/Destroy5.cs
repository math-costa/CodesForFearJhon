﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy5 : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    //chama o codigo do "Open" para quando ele e verdade destruir o item com esse codigo
    public void Update()
    {
        if (Questao51.Q51.DS51 == true && Questao52.Q52.DS52 == true && Questao53.Q53.DS53 == true)
        {
            Destroy(gameObject);
        }
    }
}
