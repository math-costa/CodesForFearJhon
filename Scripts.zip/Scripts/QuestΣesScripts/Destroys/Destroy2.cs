﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//codigo para destruiçao de objetos quando o jogador responde as resposta corretamente
public class Destroy2 : MonoBehaviour
{
    //chama o codigo do "Open" para quando ele e verdade destruir o item com esse codigo
    public void Update()
    {
        if (Questao2.Q2.DS2 == true)
        {
            Destroy(gameObject);
        }
    }
}

