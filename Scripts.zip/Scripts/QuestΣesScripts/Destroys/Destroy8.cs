﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroy8 : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    //chama o codigo do "Open" para quando ele e verdade destruir o item com esse codigo
    public void Update()
    {
        if (Questao8G.Q8G.DS8G == true && Questao8R.Q8R.DS8R == true && Questao8E.Q8E.DS8E == true && Questao8N.Q8N.DS8N == true && Questao8P.Q8P.DS8P == true && Questao8C.Q8C.DS8C == true && Questao8I.Q8I.DS8I == true && Questao8L.Q8L.DS8L == true)
        {
            Destroy(gameObject);
        }
    }
}
