﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao1 : MonoBehaviour
{
    public static Questao1 Q1 = null;

    void Awake()
    {
        if (Q1 == null)
        {
            Q1= this;
        }
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS1;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS1 = true;

        }

    }
}
