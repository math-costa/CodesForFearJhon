﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao3 : MonoBehaviour
{
    public static Questao3 Q3 = null;

    void Awake()
    {
        if (Q3 == null)
        {
            Q3 = this;
        }
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS3;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS3 = true;
        }

    }
}
