﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao8I : MonoBehaviour
{
    public static Questao8I Q8I = null;
    public GameObject I;
    public GameObject contI;
    void Awake()
    {
        if (Q8I == null)
        {
            Q8I = this;
        }
    }

    void Start()
    {
        contI = GameObject.FindWithTag("Letras");
        I = contI.transform.GetChild(18).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS8I;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS8I = true;
            I.gameObject.SetActive(true);
        }

    }
}
