﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao8C : MonoBehaviour
{
    public static Questao8C Q8C = null;
    public GameObject C;
    public GameObject contC;
    void Awake()
    {
        if (Q8C == null)
        {
            Q8C = this;
        }
    }

    void Start()
    {
        contC = GameObject.FindWithTag("Letras");
        C = contC.transform.GetChild(17).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS8C;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS8C = true;
            C.gameObject.SetActive(true);
        }

    }
}
