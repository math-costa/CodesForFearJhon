﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao8P : MonoBehaviour
{
    public static Questao8P Q8P = null;
    public GameObject P2;
    public GameObject contP2;
    void Awake()
    {
        if (Q8P == null)
        {
            Q8P = this;
        }
    }

    void Start()
    {
        contP2 = GameObject.FindWithTag("Letras");
        P2 = contP2.transform.GetChild(15).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS8P;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS8P = true;
            P2.gameObject.SetActive(true);
        }

    }
}
