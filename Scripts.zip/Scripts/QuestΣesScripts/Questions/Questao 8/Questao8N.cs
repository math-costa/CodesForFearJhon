﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao8N : MonoBehaviour
{
    public static Questao8N Q8N = null;
    public GameObject N2;
    public GameObject contN2;
    void Awake()
    {
        if (Q8N == null)
        {
            Q8N = this;
        }
    }

    void Start()
    {
        contN2 = GameObject.FindWithTag("Letras");
        N2 = contN2.transform.GetChild(14).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS8N;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS8N = true;
            N2.gameObject.SetActive(true);
        }

    }
}
