﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao8L : MonoBehaviour
{
    public static Questao8L Q8L = null;
    public GameObject L;
    public GameObject contL;
    void Awake()
    {
        if (Q8L == null)
        {
            Q8L = this;
        }
    }

    void Start()
    {
        contL = GameObject.FindWithTag("Letras");
        L = contL.transform.GetChild(19).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS8L;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS8L = true;
            L.gameObject.SetActive(true);
        }

    }
}
