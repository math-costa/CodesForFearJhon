﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao8R : MonoBehaviour
{
    public static Questao8R Q8R = null;
    public GameObject R2;
    public GameObject contR2;
    void Awake()
    {
        if (Q8R == null)
        {
            Q8R = this;
        }
    }

    void Start()
    {
        contR2 = GameObject.FindWithTag("Letras");
        R2 = contR2.transform.GetChild(11).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS8R;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS8R = true;
            R2.gameObject.SetActive(true);
        }

    }
}
