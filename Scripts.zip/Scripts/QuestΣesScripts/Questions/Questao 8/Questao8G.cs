﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao8G : MonoBehaviour
{
    public static Questao8G Q8G = null;
    public GameObject G;
    public GameObject contG;
    void Awake()
    {
        if (Q8G == null)
        {
            Q8G = this;
        }
    }

    void Start()
    {
        contG = GameObject.FindWithTag("Letras");
        G = contG.transform.GetChild(10).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS8G;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS8G = true;
            G.gameObject.SetActive(true);
        }

    }
}
