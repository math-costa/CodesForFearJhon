﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao8E : MonoBehaviour
{
    public static Questao8E Q8E = null;
    public GameObject E3;
    public GameObject E4;
    public GameObject E5;
    public GameObject contE3;
    void Awake()
    {
        if (Q8E == null)
        {
            Q8E = this;
        }
    }

    void Start()
    {
        contE3 = GameObject.FindWithTag("Letras");
        E3 = contE3.transform.GetChild(12).gameObject;
        E4 = contE3.transform.GetChild(13).gameObject;
        E5 = contE3.transform.GetChild(16).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS8E;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS8E = true;
            E3.gameObject.SetActive(true);
            E4.gameObject.SetActive(true);
            E5.gameObject.SetActive(true);

        }

    }
}
