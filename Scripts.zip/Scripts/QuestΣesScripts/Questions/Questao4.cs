﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao4 : MonoBehaviour
{
    public static Questao4 Q4 = null;

    void Awake()
    {
        if (Q4 == null)
        {
            Q4 = this;
        }
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS4;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS4 = true;
        }

    }
}
