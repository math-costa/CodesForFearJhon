﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao9 : MonoBehaviour
{
    public static Questao9 Q9 = null;

    void Awake()
    {
        if (Q9 == null)
        {
            Q9 = this;
        }
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS9;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS9 = true;
        }

    }
}
