﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao72 : MonoBehaviour
{
    public static Questao72 Q72 = null;

    void Awake()
    {
        if (Q72 == null)
        {
            Q72 = this;
        }
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS72;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS72 = true;
        }

    }
}
