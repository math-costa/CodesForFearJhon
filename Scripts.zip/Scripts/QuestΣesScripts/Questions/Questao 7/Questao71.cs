﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao71 : MonoBehaviour
{
    public static Questao71 Q71 = null;

    void Awake()
    {
        if (Q71 == null)
        {
            Q71 = this;
        }
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS71;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS71 = true;
        }

    }
}
