﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao6D : MonoBehaviour
{
    public static Questao6D Q6D = null;
    public GameObject D;
    public GameObject contD;
    void Awake()
    {
        if (Q6D == null)
        {
            Q6D = this;
        }
    }

    void Start()
    {
        contD = GameObject.FindWithTag("Letras");
        D = contD.transform.GetChild(6).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS6D;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS6D = true;
            D.gameObject.SetActive(true);
        }

    }
}
