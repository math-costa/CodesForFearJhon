﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao6R : MonoBehaviour
{
    public static Questao6R Q6R = null;
    public GameObject R;
    public GameObject contR;
    void Awake()
    {
        if (Q6R == null)
        {
            Q6R = this;
        }
    }

    void Start()
    {
        contR = GameObject.FindWithTag("Letras");
        R = contR.transform.GetChild(4).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS6R;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS6R = true;
            R.gameObject.SetActive(true);
        }

    }
}
