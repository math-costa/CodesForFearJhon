﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao6P : MonoBehaviour
{
    public static Questao6P Q6P = null;
    public GameObject P;
    public GameObject contP;
    void Awake()
    {
        if (Q6P == null)
        {
            Q6P = this;
        }
    }

    void Start()
    {
        contP = GameObject.FindWithTag("Letras");
        P = contP.transform.GetChild(7).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS6P;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS6P = true;
            P.gameObject.SetActive(true);
        }

    }
}
