﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao6E : MonoBehaviour
{
    public static Questao6E Q6E = null;
    public GameObject E1;
    public GameObject E2;
    public GameObject contE1;
    public GameObject contE2;
    void Awake()
    {
        if (Q6E == null)
        {
            Q6E = this;
        }
    }

    void Start()
    {
        contE1 = GameObject.FindWithTag("Letras");
        E1 = contE1.transform.GetChild(5).gameObject;
        contE2 = GameObject.FindWithTag("Letras");
        E2 = contE2.transform.GetChild(8).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS6E;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS6E = true;
            E1.gameObject.SetActive(true);
            E2.gameObject.SetActive(true);
        }

    }
}
