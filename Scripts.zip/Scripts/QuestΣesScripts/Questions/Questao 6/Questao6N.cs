﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao6N : MonoBehaviour
{
    public static Questao6N Q6N = null;
    public GameObject N;
    public GameObject contN;
    void Awake()
    {
        if (Q6N == null)
        {
            Q6N = this;
        }
    }

    void Start()
    {
        contN = GameObject.FindWithTag("Letras");
        N = contN.transform.GetChild(9).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS6N;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS6N = true;
            N.gameObject.SetActive(true);
        }

    }
}
