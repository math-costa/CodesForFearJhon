﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao10 : MonoBehaviour
{
    public static Questao10 Q10 = null;

    void Awake()
    {
        if (Q10 == null)
        {
            Q10 = this;
        }
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS10;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS10 = true;
        }

    }
}
