﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao51 : MonoBehaviour
{
    public static Questao51 Q51 = null;
    public GameObject B;
    public GameObject contB;
    void Awake()
    {
        if (Q51 == null)
        {
            Q51 = this;
        }
    }
    void Start()
    {
        contB = GameObject.FindWithTag("Letras");
        B = contB.transform.GetChild(0).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS51;
 
    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS51 = true;
            B.gameObject.SetActive(true);
        }
    }
    
}
