﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao53 : MonoBehaviour
{
    public static Questao53 Q53 = null;
    public GameObject K;
    public GameObject contK;

    void Awake()
    {
        if (Q53 == null)
        {
            Q53 = this;
        }
    }
    void Start()
    {
        contK = GameObject.FindWithTag("Letras");
        K = contK.transform.GetChild(3).gameObject;
        
    }


    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS53;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS53 = true;
            K.gameObject.SetActive(true);
        }
    }
}
