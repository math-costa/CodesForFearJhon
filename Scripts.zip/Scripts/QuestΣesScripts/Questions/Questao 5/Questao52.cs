﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao52 : MonoBehaviour
{
    public static Questao52 Q52 = null;
    public GameObject O1;
    public GameObject O2;
    public GameObject contO1;
    public GameObject contO2;

    void Awake()
    {
        if (Q52 == null)
        {
            Q52 = this;
        }
    }

    void Start()
    {
        contO1 = GameObject.FindWithTag("Letras");
        contO2 = GameObject.FindWithTag("Letras");
        O1 = contO2.transform.GetChild(1).gameObject;
        O2 = contO2.transform.GetChild(2).gameObject;
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS52;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS52 = true;
            O1.gameObject.SetActive(true);
            O2.gameObject.SetActive(true);
        }
    }
}
