﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Questao2 : MonoBehaviour
{
    public static Questao2 Q2 = null;

    void Awake()
    {
        if (Q2 == null)
        {
            Q2 = this;
        }
    }

    public GameObject player;// tirado do jogo linhas 20 a 24
    public bool DS2;

    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            DS2 = true;
        }

    }
}